export const Constants = {

    PAY: "PAY",
    AUTHORIZE: "AUTHORIZE",
    R2P: "INITIATE_R2P",
    RECONCILE_WALLET:"RECONCILE_WALLET",
    CARD: "CARD",
    WALLET: 'wallet',
    VOID: "VOID",
    REFUND: "REFUND",
    ECOMMERCE: "ECOMMERCE",
    MOTO: "MOTO",
    
    


}