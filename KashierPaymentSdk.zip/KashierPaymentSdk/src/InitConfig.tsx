import { axiosAPI, SERVER } from "./network/Config";


let apiKey = '';
let secretKey = '';
let merchantId = '';
let sdkMode = '';
let currency = '';
let webhookUrl = '';
let merchantRedirectUrl = '';





export function initConfig(apiKeyParam: string, secretKeyParam: string, merchantIdParam: string, webhookUrlParam: string, merchantRedirectUrlParam: string, sdkModeParam: string, currencyParam: string) {
    apiKey = apiKeyParam;
    secretKey = secretKeyParam;
    merchantId = merchantIdParam;
    sdkMode = sdkModeParam;
    currency = currencyParam;
    webhookUrl = webhookUrlParam,
    merchantRedirectUrl = merchantRedirectUrlParam
}

export function getApiKey() {
    return apiKey;
}
export function getSecretKey() {
    return secretKey;
}
export function getMerchantId() {
    return merchantId;
}
export function getSdkMode() {
    return sdkMode;
}
export function getCurrency() {
    return currency;
}
export function getWebHookUrl() {
    return webhookUrl
}
export function getMerchantRedirectUrl() {
    return merchantRedirectUrl
}
export function setSdkMode(sdkModeVal: "DEVELOPMENT" | "PRODUCTION") {
    sdkMode = sdkModeVal
    axiosAPI.defaults.baseURL = sdkModeVal === "DEVELOPMENT" ? SERVER.Feb_TEST : SERVER.Feb_PROD
}
export function setApiKey(apiKeyStr: string) {
    apiKey = apiKeyStr
}
export function setSecretKey(secretKeyStr: string) {
    secretKey = secretKeyStr
}