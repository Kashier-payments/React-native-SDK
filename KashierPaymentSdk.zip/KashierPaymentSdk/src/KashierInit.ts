import { initConfig } from "./InitConfig";


interface KashierInitParams {
  merchantId: string;
  apiKey: string;
  currency: string;
  secretKey:string;
  webHookUrl:string
  merchantRedirectUrl:string
  sdkMode: "DEVELOPMENT" | "PRODUCTION";
}

const initialize = async (params: KashierInitParams): Promise<boolean> => {
  const {
    apiKey,
    secretKey,
    merchantId,
    webHookUrl,
    merchantRedirectUrl,
    sdkMode,
    currency = "EGP",
  } = params;
  return new Promise(resolve => {
    initConfig(apiKey,secretKey,merchantId,webHookUrl,merchantRedirectUrl,sdkMode,currency)
    resolve(true);

  });
};
const KashierInit = {
  initialize
};
export { KashierInit };
