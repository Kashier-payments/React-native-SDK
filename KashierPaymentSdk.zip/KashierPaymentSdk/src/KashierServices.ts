import {
  payAuthorizeWithoutOtp,payAuthorizeWithOtp, payWithoutOtp, payWithWallet, payWithOtp,
  reconcilePayment, retriveSavedCardsTokens,
  voidPayment, refundPayment, getAvailableInstallmentsMethods
  , deleteToken,
  payWithToken,reconcileWallet
} from './network/Services'



const KashierServices = {
  payWithoutOtp,
  payWithWallet,
  voidPayment,
  refundPayment,
  payWithOtp,
  payAuthorizeWithoutOtp,
  payAuthorizeWithOtp,
  retriveSavedCardsTokens,
  reconcilePayment,
  getAvailableInstallmentsMethods,
  deleteToken,
  payWithToken,
  reconcileWallet
};
export { KashierServices };
