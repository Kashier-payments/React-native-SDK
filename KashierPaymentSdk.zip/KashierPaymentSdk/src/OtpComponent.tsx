
import React, { FC, useState, useRef } from 'react';
import { View } from 'react-native';
import { WebView } from 'react-native-webview';
import { reconcilePayment } from './network/Services';

interface OtpComponentProps {
    redirectUrl: string;
    merchantOrderId: string,
    onSuccess: () => void,
    onFailure: () => void,
}
export const OtpComponent: FC<OtpComponentProps> = ({ redirectUrl, merchantOrderId, onSuccess, onFailure }) => {


    const [url, setUrl] = useState(redirectUrl)
    const webViewRef = useRef(null);

    const checkPayment = () => {
        reconcilePayment(merchantOrderId)
            .then((responseData) => {
                // Handle successful response
                if (responseData?.status === "SUCCESS") {
                    stopWebViewLoading()
                    onSuccess()
                } else {
                    stopWebViewLoading()
                    onFailure()
                }
            })
            .catch((errorMessage: string) => {
                // Handle error
                console.error('Request failed:', errorMessage);
            })
    }
    const stopWebViewLoading = () => {
        if (webViewRef.current) {
            webViewRef.current.stopLoading();
        }
    };
    const handleNavigationChange = (navState) => {
        const { url } = navState;
        setUrl(url);
        if (url.includes('paymentStatus=SUCCESS')) {
            stopWebViewLoading()
            onSuccess()
        }
        else if (url.includes('paymentStatus=FAILED')) {
            stopWebViewLoading()
            onFailure()
        }

    };

    return (
        <View style={{ flex: 1, backgroundColor: 'white' }}>
            <WebView
                ref={webViewRef}
                source={{ uri: url }}
                onContentProcessDidTerminate={() => { checkPayment() }}
                onNavigationStateChange={handleNavigationChange}
                onShouldStartLoadWithRequest={request => {
                    return true;
                }}
            />

        </View>

    )

}
