import { KashierInit } from "./KashierInit";
import { KashierServices } from "./KashierServices";

const Kashier = {
  ...KashierInit,
  ...KashierServices,
};
export { Kashier };