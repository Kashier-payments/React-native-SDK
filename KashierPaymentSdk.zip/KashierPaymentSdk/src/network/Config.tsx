import axios from "axios";
import { getSdkMode } from "../InitConfig";



export const headers = {
    Accept: "application/json",
    "Content-Type": "application/json",
};
export enum SERVER {
    Feb_PROD = "https://fep.kashier.io/v3/",
    Feb_TEST = "https://test-fep.kashier.io/v3/",
    Kashier_TEST="https://test-api.kashier.io/",
    Kashier_PROD="https://api.kashier.io/"


}

export const axiosAPI = axios.create({
    baseURL: getSdkMode() === "DEVELOPMENT" ? SERVER.Feb_TEST : SERVER.Feb_PROD,
    headers: headers,
});

axiosAPI.interceptors.response.use(function (response) {
    return response;

}, async function (error) {
    if (401 === error?.response?.status) {

    } else {
        return Promise.reject(error);
    }
})

