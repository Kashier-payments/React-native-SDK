import { axiosAPI, SERVER } from "./Config";
import { MyResponseData } from "./interfaces/ResponseInterface";
import { Constants } from "../Constants/constants";
import { getCurrency, getMerchantId, getMerchantRedirectUrl, getSdkMode, getSecretKey, getWebHookUrl } from "../InitConfig";
import { PaymentTransactionRequest } from "./interfaces/TransactionInterface";
import { ReconcileWalletBody } from "./interfaces/ReconcileWalletBody";
import { Customer, PaymentRequest } from "./interfaces/PaymentInterface";
import { DeleteTokenModelModel, PaymentModel, TokenPaymentModel, TransactionModel, WalletPaymentModel } from "./interfaces/UserInterfaces";
function payApiRequest(payment: PaymentRequest, hash: string): Promise<MyResponseData> {

    return axiosAPI.post('orders', payment, {
        headers: {
            "Kashier-Hash": hash
        }
    })
}
function transactionApi(merchantOrderId: string, paymentTransactionRequest: PaymentTransactionRequest): Promise<MyResponseData> {

    return axiosAPI.put(`orders/${merchantOrderId}`, paymentTransactionRequest, {
        headers: { "Authorization": getSecretKey() }
    })


}
export const payWithoutOtp = ({ cardData, amount, customerReference, orderID }: PaymentModel, hash: string) => {

    const paymentRequest: PaymentRequest = {
        apiOperation: Constants.PAY,
        paymentMethod: {
            type: Constants.CARD,
            card: {
                save: cardData?.save,
                enable3DS: false,
                expiry: {
                    month: cardData?.expiryMonth,
                    year: cardData?.expiryYear
                },
                nameOnCard: cardData?.nameOnCard,
                number: cardData?.number,
                securityCode: cardData?.securityCode

            }
        },

        interactionSource: Constants.MOTO,
        reconciliation: {
            webhookUrl: getWebHookUrl(),
            merchantRedirect: getMerchantRedirectUrl(),
            redirect: false,
        },

        order: {
            reference: orderID,
            amount: amount,
            currency: getCurrency()
        },
        merchantId: getMerchantId(),
        timestamp: Date.now()
    }
    if (cardData?.save && customerReference !== undefined) {
        let customer:Customer={
            reference: customerReference
        }
        paymentRequest.customer = customer
    }
    return new Promise((resolve, reject) => {
        payApiRequest(paymentRequest, hash).then((response) => {
            const responseData: MyResponseData = response.data;

            resolve(responseData);
        })
            .catch((error) => {
                reject(error);

            });
    });
}
export const payWithOtp = ({ cardData, amount, customerReference, orderID }: PaymentModel, hash: string) => {
    const paymentRequest: PaymentRequest = {
        apiOperation: Constants.PAY,
        paymentMethod: {
            type: Constants.CARD,
            card: {
                save: cardData?.save,
                enable3DS: true,
                expiry: {
                    month: cardData?.expiryMonth,
                    year: cardData?.expiryYear
                },
                nameOnCard: cardData?.nameOnCard,
                number: cardData?.number,
                securityCode: cardData?.securityCode

            }
        },

        interactionSource: Constants.ECOMMERCE,
        reconciliation: {
            webhookUrl: getWebHookUrl(),
            merchantRedirect: getMerchantRedirectUrl(),
            redirect: true,

        },

        order: {
            reference: orderID,
            amount: amount,
            currency: getCurrency()
        },
        merchantId: getMerchantId(),
        timestamp: Date.now()
    }
 
    if (cardData?.save && customerReference !== undefined) {
        let customer:Customer={
            reference: customerReference
        }
        paymentRequest.customer = customer
    }
    return new Promise((resolve, reject) => {
        payApiRequest(paymentRequest, hash).then((response) => {
            const responseData: MyResponseData = response.data;
            resolve(responseData);
        })
            .catch((error) => {
                reject(error);

            });
    });
}
export const payAuthorizeWithoutOtp = ({ cardData, amount, customerReference, orderID }: PaymentModel, hash: string) => {

    const paymentRequest: PaymentRequest = {
        apiOperation: Constants.AUTHORIZE,
        paymentMethod: {
            type: Constants.CARD,
            card: {
                save: cardData?.save,
                enable3DS: false,
                expiry: {
                    month: cardData?.expiryMonth,
                    year: cardData?.expiryYear
                },
                nameOnCard: cardData?.nameOnCard,
                number: cardData?.number,
                securityCode: cardData?.securityCode
            }
        },

        interactionSource: Constants.ECOMMERCE,
        reconciliation: {
            webhookUrl: getWebHookUrl(),
            merchantRedirect: getMerchantRedirectUrl(),
            redirect: false,

        },
        customer: {
            reference: customerReference,

        },
        order: {
            reference: orderID,
            amount: amount,
            currency: getCurrency()
        },
        merchantId: getMerchantId(),
        timestamp: Date.now()
    }
    if (cardData?.save && customerReference !== null) {
        let customer:Customer={
            reference: customerReference
        }
        paymentRequest.customer = customer
    }
    return new Promise((resolve, reject) => {
        payApiRequest(paymentRequest, hash).then((response) => {
            // Handle successful response
            const responseData: MyResponseData = response.data;
            resolve(responseData);
        })
            .catch((error) => {
                reject(error);

            });
    });
}
export const payAuthorizeWithOtp = ({ cardData, amount, customerReference, orderID }: PaymentModel, hash: string) => {

    const paymentRequest: PaymentRequest = {
        apiOperation: Constants.AUTHORIZE,
        paymentMethod: {
            type: Constants.CARD,
            card: {
                save: cardData?.save,
                enable3DS: true,
                expiry: {
                    month: cardData?.expiryMonth,
                    year: cardData?.expiryYear
                },
                nameOnCard: cardData?.nameOnCard,
                number: cardData?.number,
                securityCode: cardData?.securityCode
            }
        },

        interactionSource: Constants.ECOMMERCE,
        reconciliation: {
            webhookUrl: getWebHookUrl(),
            merchantRedirect: getMerchantRedirectUrl(),
            redirect: false,

        },
        customer: {
            reference: customerReference,

        },
        order: {
            reference: orderID,
            amount: amount,
            currency: getCurrency()
        },
        merchantId: getMerchantId(),
        timestamp: Date.now()
    }
    if (cardData?.save && customerReference !== null) {
        let customer:Customer={
            reference: customerReference
        }
        paymentRequest.customer = customer
    }
    return new Promise((resolve, reject) => {
        payApiRequest(paymentRequest, hash).then((response) => {
            // Handle successful response
            const responseData: MyResponseData = response.data;
            resolve(responseData);
        })
            .catch((error) => {
                reject(error);

            });
    });
}
export const payWithToken = ({ cardToken, amount, customerName, customerRefrence, orderID }: TokenPaymentModel, hash: string) => {
    const payWithTokenRequest: PaymentRequest = {
        apiOperation: Constants.PAY,
        paymentMethod: {
            type: Constants.CARD,
            card: {
                cardToken: cardToken

            }
        },

        interactionSource: Constants.ECOMMERCE,
        reconciliation: {
            webhookUrl: getWebHookUrl(),
            merchantRedirect: getMerchantRedirectUrl(),
            redirect: true,

        },
        customer: {
            reference: customerRefrence,

        },
        metaData: {
            customerName: customerName
        },
        order: {
            reference: orderID,
            amount: amount,
            currency: getCurrency()
        },
        merchantId: getMerchantId(),
        timestamp: Date.now()
    }
    return new Promise((resolve, reject) => {
        payApiRequest(payWithTokenRequest, hash).then((response) => {
            // Handle successful response
            const responseData: MyResponseData = response.data;

            resolve(responseData);
        })
            .catch((error) => {
                // Handle error
                reject(error);

            });
    });

}
export const payWithWallet = ({ amount, mobileNumber, orderID }: WalletPaymentModel, hash: string) => {
    const walletRequest: PaymentRequest = {
        apiOperation: Constants.R2P,
        paymentMethod: {
            type: Constants.WALLET,

        },
        interactionSource: Constants.ECOMMERCE,
        reconciliation: {
            webhookUrl: getWebHookUrl(),
            merchantRedirect: getMerchantRedirectUrl(),

        },
        customer: {
            mobilePhone: mobileNumber
        },
        order: {
            reference: orderID,
            amount: amount,
            currency: getCurrency()
        },
        merchantId: getMerchantId(),
    }
    return new Promise((resolve, reject) => {
        payApiRequest(walletRequest, hash).then((response) => {
            const responseData: MyResponseData = response.data;
            resolve(responseData);
        })
            .catch((error) => {
                // Handle error
                reject(error.message);

            });
    });
}


/////////////// Reconcile /////////////////
export const reconcilePayment = (merchantOrderId: string) => {
    return new Promise((resolve, reject) => {
        axiosAPI.get(`payments/orders/${merchantOrderId}`, {
            baseURL: getSdkMode() === "DEVELOPMENT" ? SERVER.Kashier_TEST : SERVER.Kashier_PROD,
            headers: {
                "Authorization": getSecretKey()
            }
        })
            .then((response: any) => {
                const responseData: MyResponseData = response.data;
                resolve(responseData);
            })
            .catch((error: any) => {
                reject(error);

            });
    });
}

export const reconcileWallet = (orderId: string, hash: string) => {
    const reconileWalletBody: ReconcileWalletBody = {
        apiOperation: Constants.RECONCILE_WALLET,
        paymentMethod: {
            type: Constants.WALLET
        },
        merchantId: getMerchantId()
    }

    return new Promise((resolve, reject) => {
        axiosAPI.put(`orders/${orderId}`, reconileWalletBody, {
            headers: {
                "Kashier-Hash": hash
            },
        })
            .then((response: any) => {
                const responseData: MyResponseData = response.data;
                resolve(responseData);
            })
            .catch((error: any) => {
                reject(error);

            });
    });
}


///////////// Transactions //////////////////

export const refundPayment = ({ merchantOrderId, amount, transactionID, reason }: TransactionModel) => {
    const voidTransactionRequest: PaymentTransactionRequest = {
        apiOperation: Constants.REFUND,
        reason: reason,
        transaction: {
            amount: amount,
            targetTransactionId: transactionID
        }
    };
    return new Promise((resolve, reject) => {
        transactionApi(merchantOrderId, voidTransactionRequest).then((response: any) => {
            const responseData = response.data;
            resolve(responseData);
        })
            .catch((error: any) => {
                reject(error);

            });
    });
}
export const voidPayment = ({ merchantOrderId, amount, transactionID, reason }: TransactionModel) => {
    const voidTransactionRequest: PaymentTransactionRequest = {
        apiOperation: Constants.VOID,
        reason: reason,
        transaction: {
            amount: amount,
            targetTransactionId: transactionID
        }
    };
    return new Promise((resolve, reject) => {
        transactionApi(merchantOrderId, voidTransactionRequest).then((response: any) => {
            // Handle successful response
            const responseData = response.data;
            resolve(responseData);
        })
            .catch((error: any) => {
                reject(error);

            });
    });
}
export const retriveSavedCardsTokens = (customerReference: string, hash: string) => {
    let merchantId = getMerchantId()
    return new Promise((resolve, reject) => {

        axiosAPI.get(`cards/customer?customerReference=${customerReference}&merchantId=${merchantId}`, {
            headers: {
                "Kashier-Hash": hash
            }
        }
        ).then((response: any) => {
            const responseData = response.data;
            resolve(responseData);
        })
            .catch((error: any) => {
                reject(error);

            });
    });
}

export const deleteToken = ({ cardToken, customerReference }: DeleteTokenModelModel, hash: string) => {
    let merchantId = getMerchantId()
    return new Promise((resolve, reject) => {
        axiosAPI.delete(`cards/tokens/${cardToken}?customerReference=${customerReference}&merchantId=${merchantId}`, {
            headers: {
                "Kashier-Hash": hash
            }
        })
            .then((response: any) => {
                // Handle successful response
                const responseData = response.data;
                resolve(responseData);
            })
            .catch((error: any) => {
                reject(error);

            });
    });
}

export const getAvailableInstallmentsMethods = (amount: number) => {
    let merchantId = getMerchantId()
    return new Promise((resolve, reject) => {
        axiosAPI.get(`merchant/installments/banks/plans?mid=${merchantId}&amount=${amount}`, {
            baseURL: getSdkMode() === "DEVELOPMENT" ? SERVER.Kashier_TEST : SERVER.Kashier_PROD,
        })
            .then((response: any) => {
                const responseData = response.data;
                resolve(responseData);
            })
            .catch((error: any) => {
                reject(error.message);

            });
    });
}
