
export interface CardData {
    expiryMonth: string,
    expiryYear: string
    nameOnCard: string
    number: string,
    save:boolean
    securityCode: string
}