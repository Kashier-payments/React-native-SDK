


export interface PaymentMethod {
    type: string;
    card?: {
        save?: boolean;
        enable3DS?: boolean;
        expiry?: {
            month: string;
            year: string;
        };
        number?: string;
        nameOnCard?: string;
        securityCode?: string;
        cardToken?: string,
        type?:string
    };
}

interface Reconciliation {
    webhookUrl?: string;
    merchantRedirect?: string;
    redirect?: boolean;
}

export interface Customer {
    reference?: string;
    firstName?: string;
    lastNumber?: string;
    email?: string;
    mobilePhone?: string
    customerIp?:string
}
interface Order {
    reference?: string
    amount?: number
    currency?: string,
    description?: string,
}
interface MetaData {
    customerName: string
}
export interface PaymentRequest {
    apiOperation: string;
    paymentMethod?: PaymentMethod;
    order?: Order;
    interactionSource?: string;
    reconciliation?: Reconciliation;
    merchantId: string;
    timestamp?: number;
    customer?:Customer
    metaData?: MetaData
}

