export interface ReconcileWalletBody {
    apiOperation: string,
    paymentMethod: {
        type: string
    }
    merchantId: string
}