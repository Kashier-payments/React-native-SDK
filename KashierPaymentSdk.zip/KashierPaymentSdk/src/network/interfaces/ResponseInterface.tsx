export interface MyResponseData {

    success: boolean;
    messages: string;
    response?: any;
}