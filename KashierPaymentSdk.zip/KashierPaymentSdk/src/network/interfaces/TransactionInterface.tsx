interface Transaction {
    amount: number;
    targetTransactionId: string;
}

export interface PaymentTransactionRequest {
    apiOperation: string;
    reason: string;
    transaction: Transaction;
}

