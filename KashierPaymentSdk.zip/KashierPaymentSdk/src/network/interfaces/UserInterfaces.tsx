

export interface CardData {
    expiryMonth: string,
    expiryYear: string
    nameOnCard: string
    number: string,
    save: boolean
    securityCode: string
}
export interface PaymentModel {
    cardData: CardData,
    amount: number,
    customerReference: string,
    orderID: string

}
export interface TokenPaymentModel {
    cardToken: string,
    amount: number, 
    customerName: string,
    customerRefrence: string,
    orderID: string

}
export interface WalletPaymentModel {
    amount: number, 
    mobileNumber: string, 
    orderID:string

}
export interface TransactionModel{
    merchantOrderId: string,
    amount: number,
    transactionID: string,
    reason: string

}
export interface DeleteTokenModelModel{
    cardToken: string,
    customerReference: string

}



